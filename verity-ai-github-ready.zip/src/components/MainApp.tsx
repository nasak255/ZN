"use client";

import { useState, useRef, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  Link,
  FileText,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Shield,
  Sparkles,
  Info,
  History,
  Trash2,
  Clock,
  TrendingUp,
  Target,
  BarChart3,
  Image as ImageIcon,
  Upload,
  Zap,
  Heart,
  MessageCircle,
  Share2,
  Hash,
  Calendar,
  Users,
  Star,
  Bell,
  X,
  Globe,
  Smile,
  Frown,
  Meh,
  Angry,
  AlertCircle,
  Eye,
  ThumbsUp,
  ThumbsDown,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useAppStore, Language } from "@/store/useAppStore";
import BottomNav from "./BottomNav";
import ReportPage from "./ReportPage";
import SettingsPage from "./SettingsPage";
import InstallPrompt from "./InstallPrompt";

// Sentiment configuration
const sentimentConfig = {
  positive: { labelKey: "positive" as const, icon: Smile, color: "text-green-500", bg: "bg-green-500/10" },
  negative: { labelKey: "negative" as const, icon: Frown, color: "text-red-500", bg: "bg-red-500/10" },
  neutral: { labelKey: "neutral" as const, icon: Meh, color: "text-gray-500", bg: "bg-gray-500/10" },
  mixed: { labelKey: "mixed" as const, icon: AlertCircle, color: "text-purple-500", bg: "bg-purple-500/10" },
};

interface SentimentAnalysis {
  overall: "positive" | "negative" | "neutral" | "mixed";
  score: number;
  emotions: {
    joy: number;
    anger: number;
    fear: number;
    sadness: number;
    surprise: number;
    trust: number;
  };
  subjectivity: "objective" | "subjective" | "mixed";
  tone: string[];
}

interface AnalysisResult {
  credibilityScore: number;
  verdict: "credible" | "suspicious" | "fake" | "mixed";
  summary: string;
  keyPoints: string[];
  sources: string[];
  warnings: string[];
  positives: string[];
  sentiment: SentimentAnalysis;
  analyzedAt: string;
}

interface ImageAnalysisResult {
  description: string;
  viralityScore: number;
  viralityPrediction: "low" | "medium" | "high" | "viral";
  contentClassification: string[];
  sentiment: SentimentAnalysis;
  emotionalImpact: string;
  targetAudience: string[];
  engagementPrediction: {
    likes: string;
    shares: string;
    comments: string;
  };
  recommendations: string[];
  warnings: string[];
  contentWarnings: string[];
  hashtags: string[];
  bestPostingTime: string;
  analyzedAt: string;
}

interface HistoryItem {
  id: string;
  content: string;
  type: "text" | "url" | "image";
  result: AnalysisResult | ImageAnalysisResult;
  timestamp: Date;
}

interface Notification {
  id: string;
  title: string;
  message: string;
  type: "info" | "success" | "warning";
  timestamp: Date;
  read: boolean;
}

const verdictConfig = {
  credible: {
    labelKey: "credible" as const,
    color: "bg-green-500",
    textColor: "text-green-500",
    bgColor: "bg-green-500/10",
    icon: CheckCircle,
  },
  suspicious: {
    labelKey: "suspicious" as const,
    color: "bg-yellow-500",
    textColor: "text-yellow-500",
    bgColor: "bg-yellow-500/10",
    icon: AlertTriangle,
  },
  fake: {
    labelKey: "fake" as const,
    color: "bg-red-500",
    textColor: "text-red-500",
    bgColor: "bg-red-500/10",
    icon: XCircle,
  },
  mixed: {
    labelKey: "mixed" as const,
    color: "bg-purple-500",
    textColor: "text-purple-500",
    bgColor: "bg-purple-500/10",
    icon: Info,
  },
};

const viralityConfig = {
  low: { labelKey: "lowVirality" as const, color: "bg-gray-500" },
  medium: { labelKey: "mediumVirality" as const, color: "bg-blue-500" },
  high: { labelKey: "highVirality" as const, color: "bg-purple-500" },
  viral: { labelKey: "viralContent" as const, color: "bg-gradient-to-r from-pink-500 to-purple-500" },
};

// Translations
const translations = {
  ar: {
    positive: "إيجابي",
    negative: "سلبي",
    neutral: "محايد",
    mixed: "مختلط",
    sentimentAnalysis: "تحليل المشاعر",
    emotionalScore: "درجة المشاعر",
    emotions: "العواطف",
    joy: "الفرح",
    anger: "الغضب",
    fear: "الخوف",
    sadness: "الحزن",
    surprise: "المفاجأة",
    trust: "الثقة",
    subjectivity: "الموضوعية",
    objective: "موضوعي",
    subjective: "ذاتي",
    tone: "النبرة",
    contentWarnings: "تحذيرات المحتوى",
    notifications: "الإشعارات",
    noNotifications: "لا توجد إشعارات",
    markAsRead: "تحديد كمقروء",
    clearAll: "مسح الكل",
    home: "الرئيسية",
    report: "التقرير",
    settings: "الإعدادات",
    text: "نص",
    url: "رابط",
    image: "صورة",
    analyze: "تحليل",
    analyzing: "جاري التحليل...",
    analyzeContent: "تحليل المحتوى",
    analyzeImage: "تحليل الصورة",
    enterText: "أدخل النص الذي تريد تحليله هنا...",
    enterUrl: "أدخل رابط URL هنا...",
    uploadImage: "اضغط لرفع صورة أو اسحبها هنا",
    supportedFormats: "PNG, JPG, WEBP (صورة واحدة لكل تحليل)",
    credibilityScore: "درجة المصداقية",
    viralityScore: "درجة الانتشار",
    verdict: "النتيجة",
    credible: "موثوق",
    suspicious: "مشبوه",
    fake: "مزيف",
    summary: "ملخص التحليل",
    positives: "نقاط إيجابية",
    warnings: "تحذيرات",
    keyPoints: "النقاط الرئيسية",
    sources: "المصادر",
    imageDescription: "وصف الصورة",
    contentClassification: "تصنيف المحتوى",
    sentiment: "المشاعر",
    emotionalImpact: "التأثير العاطفي",
    targetAudience: "الجمهور المستهدف",
    engagementPrediction: "توقع التفاعل",
    likes: "الإعجابات",
    shares: "المشاركات",
    comments: "التعليقات",
    recommendedHashtags: "هاشتاجات مقترحة",
    bestPostingTime: "أفضل وقت للنشر",
    recommendations: "توصيات لزيادة الانتشار",
    lowVirality: "انتشار منخفض",
    mediumVirality: "انتشار متوسط",
    highVirality: "انتشار عالي",
    viralContent: "انتشار واسع 🚀",
    history: "السجل",
    securityNote: "🔒 يتم تحليل المحتوى بشكل آمن مع حماية خصوصيتك",
  },
  en: {
    positive: "Positive",
    negative: "Negative",
    neutral: "Neutral",
    mixed: "Mixed",
    sentimentAnalysis: "Sentiment Analysis",
    emotionalScore: "Emotional Score",
    emotions: "Emotions",
    joy: "Joy",
    anger: "Anger",
    fear: "Fear",
    sadness: "Sadness",
    surprise: "Surprise",
    trust: "Trust",
    subjectivity: "Subjectivity",
    objective: "Objective",
    subjective: "Subjective",
    tone: "Tone",
    contentWarnings: "Content Warnings",
    notifications: "Notifications",
    noNotifications: "No notifications",
    markAsRead: "Mark as read",
    clearAll: "Clear all",
    home: "Home",
    report: "Report",
    settings: "Settings",
    text: "Text",
    url: "URL",
    image: "Image",
    analyze: "Analyze",
    analyzing: "Analyzing...",
    analyzeContent: "Analyze Content",
    analyzeImage: "Analyze Image",
    enterText: "Enter the text you want to analyze...",
    enterUrl: "Enter the URL here...",
    uploadImage: "Click to upload or drag an image",
    supportedFormats: "PNG, JPG, WEBP (one image per analysis)",
    credibilityScore: "Credibility Score",
    viralityScore: "Virality Score",
    verdict: "Verdict",
    credible: "Credible",
    suspicious: "Suspicious",
    fake: "Fake",
    summary: "Analysis Summary",
    positives: "Positive Points",
    warnings: "Warnings",
    keyPoints: "Key Points",
    sources: "Sources",
    imageDescription: "Image Description",
    contentClassification: "Content Classification",
    sentiment: "Sentiment",
    emotionalImpact: "Emotional Impact",
    targetAudience: "Target Audience",
    engagementPrediction: "Engagement Prediction",
    likes: "Likes",
    shares: "Shares",
    comments: "Comments",
    recommendedHashtags: "Recommended Hashtags",
    bestPostingTime: "Best Posting Time",
    recommendations: "Recommendations",
    lowVirality: "Low Reach",
    mediumVirality: "Medium Reach",
    highVirality: "High Reach",
    viralContent: "Viral Content 🚀",
    history: "History",
    securityNote: "🔒 Content is analyzed securely with privacy protection",
  },
} as const;

type TranslationKey = keyof typeof translations.ar;

function t(language: Language, key: TranslationKey): string {
  return translations[language][key] || key;
}

export default function MainApp() {
  const { currentPage, language, stats, updateStats, isDarkMode, toggleTheme, setLanguage } = useAppStore();
  const [activeTab, setActiveTab] = useState("text");
  const [textContent, setTextContent] = useState("");
  const [urlContent, setUrlContent] = useState("");
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [imageResult, setImageResult] = useState<ImageAnalysisResult | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: "1",
      title: language === "ar" ? "مرحباً بك!" : "Welcome!",
      message: language === "ar" ? "ابدأ بتحليل المحتوى لاكتشاف المعلومات المضللة" : "Start analyzing content to detect misinformation",
      type: "info",
      timestamp: new Date(),
      read: false,
    },
    {
      id: "2",
      title: language === "ar" ? "نصيحة أمنية" : "Security Tip",
      message: language === "ar" ? "تحليلاتك محمية ومشفرة بالكامل" : "Your analyses are fully protected and encrypted",
      type: "success",
      timestamp: new Date(Date.now() - 3600000),
      read: false,
    },
  ]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const unreadCount = useMemo(() => notifications.filter(n => !n.read).length, [notifications]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Security: Validate file type
      if (!file.type.startsWith('image/')) {
        alert(language === "ar" ? "يرجى رفع ملف صورة فقط" : "Please upload an image file only");
        return;
      }
      
      // Security: Validate file size (10MB max)
      if (file.size > 10 * 1024 * 1024) {
        alert(language === "ar" ? "حجم الصورة كبير جداً. الحد الأقصى 10 ميجابايت" : "Image too large. Maximum 10MB");
        return;
      }
      
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setSelectedImage(base64);
        setImagePreview(base64);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setSelectedImage(null);
    setImagePreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleAnalyze = async () => {
    if (activeTab === "image") {
      await analyzeImage();
      return;
    }

    const content = activeTab === "text" ? textContent : urlContent;
    if (!content.trim()) return;

    setIsAnalyzing(true);
    setResult(null);
    setImageResult(null);

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: activeTab,
          content: content.trim(),
        }),
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || "Analysis failed");
      }
      
      setResult(data.result);

      // Update stats based on result
      const verdict = data.result.verdict;
      if (verdict === "credible") updateStats("credible");
      else if (verdict === "fake") updateStats("fake");
      else if (verdict === "suspicious") updateStats("suspicious");
      else updateStats("mixed");

      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        content: content.substring(0, 100) + (content.length > 100 ? "..." : ""),
        type: activeTab as "text" | "url",
        result: data.result,
        timestamp: new Date(),
      };
      setHistory((prev) => [historyItem, ...prev.slice(0, 9)]);
      
      // Add notification for completed analysis
      addNotification(
        language === "ar" ? "تم التحليل بنجاح" : "Analysis Complete",
        language === "ar" 
          ? `تم تحليل المحتوى: ${verdict === "credible" ? "موثوق" : verdict === "fake" ? "مزيف" : verdict === "suspicious" ? "مشبوه" : "مختلط"}`
          : `Content analyzed: ${verdict}`,
        verdict === "credible" ? "success" : verdict === "fake" ? "warning" : "info"
      );
    } catch (error) {
      console.error("Analysis failed:", error);
      addNotification(
        language === "ar" ? "خطأ في التحليل" : "Analysis Error",
        error instanceof Error ? error.message : "Unknown error",
        "warning"
      );
    } finally {
      setIsAnalyzing(false);
    }
  };

  const analyzeImage = async () => {
    if (!selectedImage) return;

    setIsAnalyzing(true);
    setResult(null);
    setImageResult(null);

    try {
      const response = await fetch("/api/analyze-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          image: selectedImage,
        }),
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || "Image analysis failed");
      }
      
      setImageResult(data.result);
      updateStats("image");

      const historyItem: HistoryItem = {
        id: Date.now().toString(),
        content: language === "ar" ? "تحليل صورة" : "Image analysis",
        type: "image",
        result: data.result,
        timestamp: new Date(),
      };
      setHistory((prev) => [historyItem, ...prev.slice(0, 9)]);
      
      addNotification(
        language === "ar" ? "تم تحليل الصورة" : "Image Analyzed",
        language === "ar" 
          ? `درجة الانتشار المتوقعة: ${data.result.viralityScore}%`
          : `Predicted virality score: ${data.result.viralityScore}%`,
        "success"
      );
    } catch (error) {
      console.error("Image analysis failed:", error);
      addNotification(
        language === "ar" ? "خطأ في تحليل الصورة" : "Image Analysis Error",
        error instanceof Error ? error.message : "Unknown error",
        "warning"
      );
    } finally {
      setIsAnalyzing(false);
    }
  };

  const addNotification = (title: string, message: string, type: "info" | "success" | "warning") => {
    const notification: Notification = {
      id: Date.now().toString(),
      title,
      message,
      type,
      timestamp: new Date(),
      read: false,
    };
    setNotifications((prev) => [notification, ...prev.slice(0, 19)]);
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const clearNotifications = () => {
    setNotifications([]);
  };

  const clearHistory = () => {
    setHistory([]);
  };

  // Render different pages based on currentPage
  if (currentPage === "report") {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <InstallPrompt />
        <Header 
          language={language}
          setLanguage={setLanguage}
          isDarkMode={isDarkMode}
          toggleTheme={toggleTheme}
          showLangMenu={showLangMenu}
          setShowLangMenu={setShowLangMenu}
          showNotifications={showNotifications}
          setShowNotifications={setShowNotifications}
          notifications={notifications}
          unreadCount={unreadCount}
          markNotificationRead={markNotificationRead}
          clearNotifications={clearNotifications}
          t={(key: TranslationKey) => t(language, key)}
        />
        <main className="max-w-4xl mx-auto px-4 py-6">
          <ReportPage />
        </main>
        <BottomNav />
      </div>
    );
  }

  if (currentPage === "settings") {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <InstallPrompt />
        <Header 
          language={language}
          setLanguage={setLanguage}
          isDarkMode={isDarkMode}
          toggleTheme={toggleTheme}
          showLangMenu={showLangMenu}
          setShowLangMenu={setShowLangMenu}
          showNotifications={showNotifications}
          setShowNotifications={setShowNotifications}
          notifications={notifications}
          unreadCount={unreadCount}
          markNotificationRead={markNotificationRead}
          clearNotifications={clearNotifications}
          t={(key: TranslationKey) => t(language, key)}
        />
        <main className="max-w-4xl mx-auto px-4 py-6">
          <SettingsPage />
        </main>
        <BottomNav />
      </div>
    );
  }

  // Home page
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <InstallPrompt />
      
      <Header 
        language={language}
        setLanguage={setLanguage}
        isDarkMode={isDarkMode}
        toggleTheme={toggleTheme}
        showLangMenu={showLangMenu}
        setShowLangMenu={setShowLangMenu}
        showHistoryButton
        onHistoryClick={() => setShowHistory(!showHistory)}
        showNotifications={showNotifications}
        setShowNotifications={setShowNotifications}
        notifications={notifications}
        unreadCount={unreadCount}
        markNotificationRead={markNotificationRead}
        clearNotifications={clearNotifications}
        t={(key: TranslationKey) => t(language, key)}
      />

      <main className="max-w-4xl mx-auto px-4 py-6 pb-28">
        <div className="space-y-6">
          {/* Security Note */}
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-3 rounded-xl bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border border-green-100 dark:border-green-800"
          >
            <p className="text-sm text-green-700 dark:text-green-300 flex items-center gap-2">
              <Shield className="w-4 h-4" />
              {t(language, "securityNote")}
            </p>
          </motion.div>

          {/* Input Card */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <Card className="border-0 shadow-xl bg-white dark:bg-gray-800">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <motion.div
                    animate={{ rotate: [0, 360] }}
                    transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                  >
                    <Search className="w-5 h-5 text-purple-500" />
                  </motion.div>
                  {t(language, "analyzeContent")}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-3 h-12">
                    <TabsTrigger value="text" className="gap-2">
                      <FileText className="w-4 h-4" />
                      {t(language, "text")}
                    </TabsTrigger>
                    <TabsTrigger value="url" className="gap-2">
                      <Link className="w-4 h-4" />
                      {t(language, "url")}
                    </TabsTrigger>
                    <TabsTrigger value="image" className="gap-2">
                      <ImageIcon className="w-4 h-4" />
                      {t(language, "image")}
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="text" className="mt-4">
                    <Textarea
                      placeholder={t(language, "enterText")}
                      value={textContent}
                      onChange={(e) => setTextContent(e.target.value)}
                      className="min-h-[150px] resize-none bg-gray-50 dark:bg-gray-700 border-0"
                      dir={language === "ar" ? "rtl" : "ltr"}
                      maxLength={10000}
                    />
                    <p className="text-xs text-gray-400 mt-1 text-left" dir="ltr">
                      {textContent.length} / 10,000
                    </p>
                  </TabsContent>

                  <TabsContent value="url" className="mt-4">
                    <Input
                      type="url"
                      placeholder={t(language, "enterUrl")}
                      value={urlContent}
                      onChange={(e) => setUrlContent(e.target.value)}
                      className="bg-gray-50 dark:bg-gray-700 border-0 h-12"
                      dir="ltr"
                    />
                  </TabsContent>

                  <TabsContent value="image" className="mt-4">
                    {imagePreview ? (
                      <div className="relative">
                        <img
                          src={imagePreview}
                          alt="Preview"
                          className="w-full max-h-[300px] object-contain rounded-xl bg-gray-50 dark:bg-gray-700"
                        />
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={removeImage}
                          className="absolute top-2 left-2 rounded-full w-8 h-8 p-0"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                        <div className="absolute bottom-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded">
                          {language === "ar" ? "صورة واحدة للتحليل" : "Single image for analysis"}
                        </div>
                      </div>
                    ) : (
                      <label className="flex flex-col items-center justify-center w-full h-[200px] border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl cursor-pointer hover:border-purple-500 transition-colors bg-gray-50 dark:bg-gray-700/50">
                        <Upload className="w-10 h-10 text-gray-400 mb-2" />
                        <span className="text-sm text-gray-500">{t(language, "uploadImage")}</span>
                        <span className="text-xs text-gray-400 mt-1">{t(language, "supportedFormats")}</span>
                        <input
                          ref={fileInputRef}
                          type="file"
                          accept="image/jpeg,image/png,image/webp,image/gif"
                          className="hidden"
                          onChange={handleImageUpload}
                        />
                      </label>
                    )}
                  </TabsContent>
                </Tabs>

                <Button
                  onClick={handleAnalyze}
                  disabled={isAnalyzing || (activeTab === "image" ? !selectedImage : !(activeTab === "text" ? textContent.trim() : urlContent.trim()))}
                  className="w-full bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 text-white py-6 text-lg font-semibold rounded-xl"
                >
                  {isAnalyzing ? (
                    <>
                      <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: "linear" }}>
                        <Sparkles className="w-5 h-5" />
                      </motion.div>
                      {t(language, "analyzing")}
                    </>
                  ) : (
                    <>
                      <Zap className="w-5 h-5" />
                      {activeTab === "image" ? t(language, "analyzeImage") : t(language, "analyze")}
                    </>
                  )}
                </Button>
              </CardContent>
            </Card>
          </motion.div>

          {/* Results */}
          <AnimatePresence mode="wait">
            {result && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
                <ResultCard result={result} language={language} t={(key: TranslationKey) => t(language, key)} />
              </motion.div>
            )}
            {imageResult && (
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}>
                <ImageResultCard result={imageResult} language={language} t={(key: TranslationKey) => t(language, key)} />
              </motion.div>
            )}
          </AnimatePresence>

          {/* History Sidebar */}
          <AnimatePresence>
            {showHistory && (
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }}>
                <Card className="border-0 shadow-xl bg-white dark:bg-gray-800">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center gap-2">
                        <History className="w-5 h-5 text-purple-500" />
                        {t(language, "history")}
                      </CardTitle>
                      {history.length > 0 && (
                        <Button variant="ghost" size="sm" onClick={clearHistory} className="text-red-500">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    {history.length === 0 ? (
                      <p className="text-sm text-gray-500 text-center py-4">
                        {language === "ar" ? "لا توجد تحليلات سابقة" : "No previous analyses"}
                      </p>
                    ) : (
                      <ScrollArea className="h-[300px]">
                        <div className="space-y-3">
                          {history.map((item) => (
                            <div
                              key={item.id}
                              className="p-3 rounded-xl bg-gray-50 dark:bg-gray-700 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                              onClick={() => {
                                if ("viralityPrediction" in item.result) {
                                  setImageResult(item.result as ImageAnalysisResult);
                                  setResult(null);
                                } else {
                                  setResult(item.result as AnalysisResult);
                                  setImageResult(null);
                                }
                              }}
                            >
                              <div className="flex items-center justify-between mb-1">
                                <Badge variant="outline" className="text-purple-500">
                                  {item.type === "image" ? t(language, "image") : t(language, "text")}
                                </Badge>
                              </div>
                              <p className="text-sm text-gray-600 dark:text-gray-300 truncate">{item.content}</p>
                              <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {item.timestamp.toLocaleTimeString(language === "ar" ? "ar-SA" : "en-US")}
                              </p>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
      <BottomNav />
    </div>
  );
}

// Header Component
function Header({ 
  language, 
  setLanguage, 
  isDarkMode, 
  toggleTheme, 
  showLangMenu, 
  setShowLangMenu, 
  showHistoryButton,
  onHistoryClick,
  showNotifications,
  setShowNotifications,
  notifications,
  unreadCount,
  markNotificationRead,
  clearNotifications,
  t
}: { 
  language: Language;
  setLanguage: (lang: Language) => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
  showLangMenu: boolean;
  setShowLangMenu: (show: boolean) => void;
  showHistoryButton?: boolean;
  onHistoryClick?: () => void;
  showNotifications: boolean;
  setShowNotifications: (show: boolean) => void;
  notifications: Notification[];
  unreadCount: number;
  markNotificationRead: (id: string) => void;
  clearNotifications: () => void;
  t: (key: TranslationKey) => string;
}) {
  return (
    <header className="sticky top-0 z-40 bg-white/90 dark:bg-gray-900/90 backdrop-blur-xl border-b border-gray-200/50 dark:border-gray-700/50">
      <div className="max-w-4xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-3"
          >
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-500 via-purple-500 to-indigo-500 flex items-center justify-center shadow-lg shadow-purple-500/20"
            >
              <Shield className="w-5 h-5 text-white" />
            </motion.div>
            <div>
              <h1 className="text-lg font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                Verity AI
              </h1>
              <p className="text-xs text-gray-500 dark:text-gray-400">
                {language === "ar" ? "كشف المحتوى المضلل" : "Misinformation Detection"}
              </p>
            </div>
          </motion.div>

          <div className="flex items-center gap-1">
            {showHistoryButton && onHistoryClick && (
              <Button variant="ghost" size="icon" onClick={onHistoryClick} className="rounded-xl">
                <History className="w-5 h-5" />
              </Button>
            )}
            
            {/* Notifications Button */}
            <div className="relative">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setShowNotifications(!showNotifications)} 
                className="rounded-xl"
              >
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </Button>
              
              <AnimatePresence>
                {showNotifications && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute top-full right-0 mt-2 w-80 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden z-50"
                  >
                    <div className="p-3 border-b border-gray-200 dark:border-gray-700 flex items-center justify-between">
                      <h3 className="font-semibold">{t("notifications")}</h3>
                      {notifications.length > 0 && (
                        <Button variant="ghost" size="sm" onClick={clearNotifications} className="text-xs">
                          {t("clearAll")}
                        </Button>
                      )}
                    </div>
                    <ScrollArea className="max-h-80">
                      {notifications.length === 0 ? (
                        <p className="text-sm text-gray-500 text-center py-4">{t("noNotifications")}</p>
                      ) : (
                        <div className="divide-y divide-gray-100 dark:divide-gray-700">
                          {notifications.map((n) => (
                            <div
                              key={n.id}
                              onClick={() => markNotificationRead(n.id)}
                              className={`p-3 cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 ${!n.read ? "bg-purple-50 dark:bg-purple-900/20" : ""}`}
                            >
                              <div className="flex items-start gap-2">
                                {n.type === "success" && <CheckCircle className="w-4 h-4 text-green-500 mt-0.5" />}
                                {n.type === "warning" && <AlertTriangle className="w-4 h-4 text-yellow-500 mt-0.5" />}
                                {n.type === "info" && <Info className="w-4 h-4 text-blue-500 mt-0.5" />}
                                <div className="flex-1">
                                  <p className="font-medium text-sm">{n.title}</p>
                                  <p className="text-xs text-gray-500">{n.message}</p>
                                  <p className="text-xs text-gray-400 mt-1">
                                    {n.timestamp.toLocaleTimeString(language === "ar" ? "ar-SA" : "en-US")}
                                  </p>
                                </div>
                                {!n.read && <div className="w-2 h-2 rounded-full bg-purple-500" />}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </ScrollArea>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            
            <Button variant="ghost" size="icon" onClick={toggleTheme} className="rounded-xl">
              {isDarkMode ? <Sparkles className="w-5 h-5 text-yellow-400" /> : <Shield className="w-5 h-5" />}
            </Button>

            <div className="relative">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setShowLangMenu(!showLangMenu)}
                className="rounded-xl"
              >
                <Globe className="w-5 h-5" />
              </Button>
              
              <AnimatePresence>
                {showLangMenu && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute top-full right-0 mt-2 bg-white dark:bg-gray-800 rounded-xl shadow-xl border border-gray-200 dark:border-gray-700 overflow-hidden z-50"
                  >
                    <button
                      onClick={() => { setLanguage("ar"); setShowLangMenu(false); }}
                      className={`flex items-center gap-2 px-4 py-2 w-full text-right hover:bg-gray-100 dark:hover:bg-gray-700 ${language === "ar" ? "bg-purple-50 dark:bg-purple-900/30 text-purple-600" : ""}`}
                    >
                      🇸🇦 العربية
                    </button>
                    <button
                      onClick={() => { setLanguage("en"); setShowLangMenu(false); }}
                      className={`flex items-center gap-2 px-4 py-2 w-full text-left hover:bg-gray-100 dark:hover:bg-gray-700 ${language === "en" ? "bg-purple-50 dark:bg-purple-900/30 text-purple-600" : ""}`}
                    >
                      🇺🇸 English
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

// Sentiment Indicator Component
function SentimentIndicator({ sentiment, language, t }: { sentiment: SentimentAnalysis; language: Language; t: (key: TranslationKey) => string }) {
  const config = sentimentConfig[sentiment.overall];
  const Icon = config.icon;
  
  return (
    <Card className="border-0 shadow-lg overflow-hidden">
      <div className="h-1 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500" />
      <CardContent className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <h4 className="font-semibold flex items-center gap-2">
            <Eye className="w-4 h-4 text-purple-500" />
            {t("sentimentAnalysis")}
          </h4>
          <div className={`flex items-center gap-1 px-3 py-1 rounded-full ${config.bg}`}>
            <Icon className={`w-4 h-4 ${config.color}`} />
            <span className={`text-sm font-medium ${config.color}`}>{t(config.labelKey)}</span>
          </div>
        </div>
        
        {/* Emotional Score */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-500">{t("emotionalScore")}</span>
            <span className={`font-bold ${sentiment.score > 0 ? "text-green-500" : sentiment.score < 0 ? "text-red-500" : "text-gray-500"}`}>
              {sentiment.score > 0 ? "+" : ""}{sentiment.score}
            </span>
          </div>
          <div className="relative h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <div 
              className="absolute h-full bg-gradient-to-r from-red-500 via-yellow-500 to-green-500"
              style={{ width: `${(sentiment.score + 100) / 2}%` }}
            />
            <div 
              className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-white border-2 border-purple-500 rounded-full shadow"
              style={{ left: `calc(${(sentiment.score + 100) / 2}% - 6px)` }}
            />
          </div>
          <div className="flex justify-between text-xs text-gray-400">
            <span>{language === "ar" ? "سلبي جداً" : "Very Negative"}</span>
            <span>{language === "ar" ? "إيجابي جداً" : "Very Positive"}</span>
          </div>
        </div>
        
        {/* Emotions */}
        <div>
          <h5 className="text-sm font-medium text-gray-500 mb-2">{t("emotions")}</h5>
          <div className="grid grid-cols-3 gap-2">
            {[
              { key: "joy", icon: Smile, color: "text-yellow-500" },
              { key: "anger", icon: Angry, color: "text-red-500" },
              { key: "fear", icon: AlertCircle, color: "text-purple-500" },
              { key: "sadness", icon: Frown, color: "text-blue-500" },
              { key: "surprise", icon: AlertTriangle, color: "text-orange-500" },
              { key: "trust", icon: ThumbsUp, color: "text-green-500" },
            ].map((emotion) => (
              <div key={emotion.key} className="flex flex-col items-center p-2 rounded-lg bg-gray-50 dark:bg-gray-700/50">
                <emotion.icon className={`w-4 h-4 ${emotion.color} mb-1`} />
                <span className="text-xs font-bold">{sentiment.emotions[emotion.key as keyof typeof sentiment.emotions]}%</span>
                <span className="text-xs text-gray-500">{t(emotion.key as TranslationKey)}</span>
              </div>
            ))}
          </div>
        </div>
        
        {/* Subjectivity & Tone */}
        <div className="grid grid-cols-2 gap-3">
          <div className="p-2 rounded-lg bg-gray-50 dark:bg-gray-700/50">
            <p className="text-xs text-gray-500">{t("subjectivity")}</p>
            <p className="text-sm font-medium">{t(sentiment.subjectivity as TranslationKey)}</p>
          </div>
          <div className="p-2 rounded-lg bg-gray-50 dark:bg-gray-700/50">
            <p className="text-xs text-gray-500">{t("tone")}</p>
            <div className="flex flex-wrap gap-1 mt-1">
              {sentiment.tone.slice(0, 2).map((tone, i) => (
                <Badge key={i} variant="secondary" className="text-xs">{tone}</Badge>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// Result Card Component
function ResultCard({ result, language, t }: { result: AnalysisResult; language: Language; t: (key: TranslationKey) => string }) {
  const config = verdictConfig[result.verdict];
  const Icon = config.icon;
  
  return (
    <div className="space-y-4">
      <Card className="border-0 shadow-xl bg-white dark:bg-gray-800 overflow-hidden">
        <div className={`${config.bgColor} p-6`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className={`w-12 h-12 rounded-2xl ${config.bgColor} flex items-center justify-center`}
              >
                <Icon className={`w-6 h-6 ${config.textColor}`} />
              </motion.div>
              <div>
                <h3 className="text-xl font-bold">{t(config.labelKey)}</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">{t("verdict")}</p>
              </div>
            </div>
            <div className="text-left">
              <div className="text-3xl font-bold">{result.credibilityScore}%</div>
              <p className="text-sm text-gray-500">{t("credibilityScore")}</p>
            </div>
          </div>
          <div className="mt-4">
            <Progress value={result.credibilityScore} className="h-2" />
          </div>
        </div>
        <CardContent className="p-6 space-y-4">
          <div>
            <h4 className="font-semibold mb-2">{t("summary")}</h4>
            <p className="text-gray-600 dark:text-gray-300 text-sm">{result.summary}</p>
          </div>
          {result.positives.length > 0 && (
            <div className="p-3 rounded-xl bg-green-50 dark:bg-green-900/20">
              <h5 className="font-medium text-green-700 dark:text-green-400 mb-1 flex items-center gap-2">
                <ThumbsUp className="w-4 h-4" />
                {t("positives")}
              </h5>
              <ul className="text-sm text-green-600 dark:text-green-300 space-y-1">
                {result.positives.map((p, i) => <li key={i}>• {p}</li>)}
              </ul>
            </div>
          )}
          {result.warnings.length > 0 && (
            <div className="p-3 rounded-xl bg-red-50 dark:bg-red-900/20">
              <h5 className="font-medium text-red-700 dark:text-red-400 mb-1 flex items-center gap-2">
                <ThumbsDown className="w-4 h-4" />
                {t("warnings")}
              </h5>
              <ul className="text-sm text-red-600 dark:text-red-300 space-y-1">
                {result.warnings.map((w, i) => <li key={i}>• {w}</li>)}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Sentiment Analysis */}
      {result.sentiment && (
        <SentimentIndicator sentiment={result.sentiment} language={language} t={t} />
      )}
    </div>
  );
}

// Image Result Card Component
function ImageResultCard({ result, language, t }: { result: ImageAnalysisResult; language: Language; t: (key: TranslationKey) => string }) {
  return (
    <div className="space-y-4">
      <Card className="border-0 shadow-xl bg-white dark:bg-gray-800 overflow-hidden">
        <div className="bg-gradient-to-br from-purple-500 via-pink-500 to-indigo-500 p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center"
              >
                <TrendingUp className="w-6 h-6" />
              </motion.div>
              <div>
                <h3 className="text-xl font-bold">{t(viralityConfig[result.viralityPrediction].labelKey)}</h3>
                <p className="text-sm text-white/80">{t("viralityScore")}</p>
              </div>
            </div>
            <div className="text-left">
              <div className="text-3xl font-bold">{result.viralityScore}</div>
            </div>
          </div>
          <div className="mt-4">
            <Progress value={result.viralityScore} className="h-2 bg-white/20" />
          </div>
        </div>
        <CardContent className="p-6 space-y-4">
          <div>
            <h4 className="font-semibold mb-2">{t("imageDescription")}</h4>
            <p className="text-gray-600 dark:text-gray-300 text-sm">{result.description}</p>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 rounded-xl bg-purple-50 dark:bg-purple-900/20">
              <h5 className="font-medium text-purple-700 dark:text-purple-400 text-sm mb-1">{t("contentClassification")}</h5>
              <div className="flex flex-wrap gap-1">
                {result.contentClassification.map((c, i) => (
                  <Badge key={i} variant="secondary" className="text-xs">{c}</Badge>
                ))}
              </div>
            </div>
            <div className="p-3 rounded-xl bg-pink-50 dark:bg-pink-900/20">
              <h5 className="font-medium text-pink-700 dark:text-pink-400 text-sm mb-1">{t("emotionalImpact")}</h5>
              <p className="text-sm text-pink-600">{result.emotionalImpact}</p>
            </div>
          </div>
          <div className="p-3 rounded-xl bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20">
            <h5 className="font-medium text-indigo-700 dark:text-indigo-400 text-sm mb-2">{t("engagementPrediction")}</h5>
            <div className="grid grid-cols-3 gap-2 text-center text-sm">
              <div>
                <Heart className="w-4 h-4 mx-auto text-pink-500 mb-1" />
                <p className="text-xs text-gray-500">{t("likes")}</p>
                <p className="font-bold text-pink-600">{result.engagementPrediction.likes}</p>
              </div>
              <div>
                <Share2 className="w-4 h-4 mx-auto text-blue-500 mb-1" />
                <p className="text-xs text-gray-500">{t("shares")}</p>
                <p className="font-bold text-blue-600">{result.engagementPrediction.shares}</p>
              </div>
              <div>
                <MessageCircle className="w-4 h-4 mx-auto text-green-500 mb-1" />
                <p className="text-xs text-gray-500">{t("comments")}</p>
                <p className="font-bold text-green-600">{result.engagementPrediction.comments}</p>
              </div>
            </div>
          </div>
          <div>
            <h4 className="font-semibold mb-2 flex items-center gap-2">
              <Hash className="w-4 h-4 text-purple-500" />
              {t("recommendedHashtags")}
            </h4>
            <div className="flex flex-wrap gap-1">
              {result.hashtags.map((tag, i) => (
                <Badge key={i} className="bg-gradient-to-r from-pink-500 to-purple-500 text-white text-xs">{tag}</Badge>
              ))}
            </div>
          </div>
          <div className="p-3 rounded-xl bg-yellow-50 dark:bg-yellow-900/20">
            <h5 className="font-medium text-yellow-700 dark:text-yellow-400 text-sm flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              {t("bestPostingTime")}
            </h5>
            <p className="text-sm text-yellow-600 mt-1">{result.bestPostingTime}</p>
          </div>
          {result.recommendations.length > 0 && (
            <div className="p-3 rounded-xl bg-green-50 dark:bg-green-900/20">
              <h5 className="font-medium text-green-700 dark:text-green-400 text-sm mb-1 flex items-center gap-2">
                <Star className="w-4 h-4" />
                {t("recommendations")}
              </h5>
              <ul className="text-sm text-green-600 dark:text-green-300 space-y-1">
                {result.recommendations.map((r, i) => <li key={i}>• {r}</li>)}
              </ul>
            </div>
          )}
          {result.contentWarnings && result.contentWarnings.length > 0 && (
            <div className="p-3 rounded-xl bg-orange-50 dark:bg-orange-900/20">
              <h5 className="font-medium text-orange-700 dark:text-orange-400 text-sm mb-1 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                {t("contentWarnings")}
              </h5>
              <ul className="text-sm text-orange-600 dark:text-orange-300 space-y-1">
                {result.contentWarnings.map((w, i) => <li key={i}>• {w}</li>)}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Sentiment Analysis for Image */}
      {result.sentiment && (
        <SentimentIndicator sentiment={result.sentiment} language={language} t={t} />
      )}
    </div>
  );
}
