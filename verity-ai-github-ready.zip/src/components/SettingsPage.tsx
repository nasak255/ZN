"use client";

import { motion } from "framer-motion";
import {
  Moon,
  Sun,
  Bell,
  BellOff,
  Globe,
  Shield,
  Heart,
  ChevronLeft,
  Trash2,
  Share2,
  Info,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { useAppStore, Language } from "@/store/useAppStore";

// Local translations
const translations = {
  ar: {
    settings: "الإعدادات",
    language: "اللغة",
    appearance: "المظهر",
    darkMode: "الوضع الليلي",
    lightMode: "الوضع النهاري",
    enabled: "مفعّل",
    notifications: "الإشعارات",
    enableNotifications: "تفعيل الإشعارات",
    notificationsDesc: "تلقي إشعارات حول التحليلات الجديدة",
    yourStats: "إحصائياتك",
    totalAnalyses: "إجمالي التحليلات",
    imageAnalyses: "تحليلات الصور",
    aboutApp: "حول التطبيق",
    aboutDesc: "منصة ذكية لكشف المحتوى المضلل والأخبار الكاذبة باستخدام الذكاء الاصطناعي. نستخدم نماذج متقدمة لتحليل النصوص والصور والروابط.",
    madeWith: "صُنع بـ ❤️ لمساعدتك على التحقق",
    shareApp: "مشاركة التطبيق",
    shareText: "تطبيق ذكي لكشف المحتوى المضلل",
    privacyPolicy: "سياسة الخصوصية",
    termsOfService: "شروط الاستخدام",
    mobileApp: "تطبيق موبايل",
  },
  en: {
    settings: "Settings",
    language: "Language",
    appearance: "Appearance",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    enabled: "Enabled",
    notifications: "Notifications",
    enableNotifications: "Enable Notifications",
    notificationsDesc: "Receive notifications about new analyses",
    yourStats: "Your Stats",
    totalAnalyses: "Total Analyses",
    imageAnalyses: "Image Analyses",
    aboutApp: "About App",
    aboutDesc: "An intelligent platform for detecting misinformation using AI. We use advanced models to analyze texts, images, and links.",
    madeWith: "Made with ❤️ to help you verify",
    shareApp: "Share App",
    shareText: "Smart app for detecting misinformation",
    privacyPolicy: "Privacy Policy",
    termsOfService: "Terms of Service",
    mobileApp: "Mobile App",
  },
} as const;

type TranslationKey = keyof typeof translations.ar;

function t(language: Language, key: TranslationKey): string {
  return translations[language][key] || key;
}

export default function SettingsPage() {
  const {
    language,
    setLanguage,
    isDarkMode,
    toggleTheme,
    notificationsEnabled,
    toggleNotifications,
    stats,
  } = useAppStore();

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center py-6"
      >
        <h1 className="text-2xl font-bold bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent">
          {t(language, "settings")}
        </h1>
      </motion.div>

      {/* Language Settings */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Card className="border-0 shadow-xl overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-pink-500 to-purple-500" />
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Globe className="w-5 h-5 text-purple-500" />
              {t(language, "language")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setLanguage("ar")}
                className={`h-20 flex flex-col items-center justify-center gap-2 rounded-xl transition-all ${
                  language === "ar"
                    ? "bg-gradient-to-br from-pink-500 to-purple-500 text-white shadow-lg"
                    : "bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700"
                }`}
              >
                <span className="text-3xl">🇸🇦</span>
                <span className="font-semibold">العربية</span>
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setLanguage("en")}
                className={`h-20 flex flex-col items-center justify-center gap-2 rounded-xl transition-all ${
                  language === "en"
                    ? "bg-gradient-to-br from-pink-500 to-purple-500 text-white shadow-lg"
                    : "bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700"
                }`}
              >
                <span className="text-3xl">🇺🇸</span>
                <span className="font-semibold">English</span>
              </motion.button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Appearance */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="border-0 shadow-xl overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-purple-500 to-indigo-500" />
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              {isDarkMode ? (
                <Moon className="w-5 h-5 text-purple-500" />
              ) : (
                <Sun className="w-5 h-5 text-yellow-500" />
              )}
              {t(language, "appearance")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between p-3 rounded-xl bg-gray-50 dark:bg-gray-800">
              <div className="flex items-center gap-3">
                <motion.div
                  animate={{ rotate: isDarkMode ? 0 : 180 }}
                  className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                    isDarkMode
                      ? "bg-gray-800"
                      : "bg-gradient-to-br from-yellow-200 to-orange-200"
                  }`}
                >
                  {isDarkMode ? (
                    <Moon className="w-5 h-5 text-purple-400" />
                  ) : (
                    <Sun className="w-5 h-5 text-yellow-600" />
                  )}
                </motion.div>
                <div>
                  <p className="font-medium">
                    {isDarkMode
                      ? t(language, "darkMode")
                      : t(language, "lightMode")}
                  </p>
                  <p className="text-xs text-gray-500">
                    {t(language, "enabled")}
                  </p>
                </div>
              </div>
              <Switch
                checked={isDarkMode}
                onCheckedChange={toggleTheme}
                className="data-[state=checked]:bg-purple-500"
              />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Notifications */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="border-0 shadow-xl overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-indigo-500 to-blue-500" />
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              {notificationsEnabled ? (
                <Bell className="w-5 h-5 text-purple-500" />
              ) : (
                <BellOff className="w-5 h-5 text-gray-400" />
              )}
              {t(language, "notifications")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between p-3 rounded-xl bg-gray-50 dark:bg-gray-800">
              <div>
                <p className="font-medium">
                  {t(language, "enableNotifications")}
                </p>
                <p className="text-xs text-gray-500">
                  {t(language, "notificationsDesc")}
                </p>
              </div>
              <Switch
                checked={notificationsEnabled}
                onCheckedChange={toggleNotifications}
                className="data-[state=checked]:bg-purple-500"
              />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Stats Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card className="border-0 shadow-xl bg-gradient-to-br from-purple-500 via-pink-500 to-indigo-500 text-white overflow-hidden">
          <CardContent className="p-6">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5" />
              {t(language, "yourStats")}
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white/10 rounded-xl p-3 text-center backdrop-blur">
                <p className="text-2xl font-bold">{stats.totalAnalysis}</p>
                <p className="text-xs text-white/80">
                  {t(language, "totalAnalyses")}
                </p>
              </div>
              <div className="bg-white/10 rounded-xl p-3 text-center backdrop-blur">
                <p className="text-2xl font-bold">{stats.imageAnalysisCount}</p>
                <p className="text-xs text-white/80">
                  {t(language, "imageAnalyses")}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* About App */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <Card className="border-0 shadow-xl overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-pink-500 to-purple-500" />
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Info className="w-5 h-5 text-purple-500" />
              {t(language, "aboutApp")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-4">
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="w-16 h-16 rounded-2xl bg-gradient-to-br from-pink-500 to-purple-500 flex items-center justify-center shadow-lg"
              >
                <Shield className="w-8 h-8 text-white" />
              </motion.div>
              <div>
                <h4 className="font-bold text-lg">Verity AI</h4>
                <p className="text-sm text-gray-500">الإصدار 2.0.0</p>
                <Badge variant="secondary" className="mt-1">
                  {t(language, "mobileApp")}
                </Badge>
              </div>
            </div>

            <Separator />

            <p className="text-sm text-gray-600 dark:text-gray-300 leading-relaxed">
              {t(language, "aboutDesc")}
            </p>

            <div className="flex items-center gap-2 text-sm text-gray-500">
              <Heart className="w-4 h-4 text-red-500" />
              {t(language, "madeWith")}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Share App */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        <Button
          className="w-full h-14 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 text-white rounded-xl shadow-lg"
          onClick={() => {
            if (navigator.share) {
              navigator.share({
                title: "Verity AI",
                text: t(language, "shareText"),
                url: window.location.href,
              });
            }
          }}
        >
          <Share2 className="w-5 h-5 mr-2" />
          {t(language, "shareApp")}
        </Button>
      </motion.div>

      {/* Legal Links */}
      <div className="space-y-2">
        <Button
          variant="outline"
          className="w-full justify-between h-12 rounded-xl"
        >
          <span>{t(language, "privacyPolicy")}</span>
          <ChevronLeft className="w-4 h-4 rotate-180" />
        </Button>
        <Button
          variant="outline"
          className="w-full justify-between h-12 rounded-xl"
        >
          <span>{t(language, "termsOfService")}</span>
          <ChevronLeft className="w-4 h-4 rotate-180" />
        </Button>
      </div>
    </div>
  );
}
