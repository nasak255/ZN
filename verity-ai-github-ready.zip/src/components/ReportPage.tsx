"use client";

import { motion } from "framer-motion";
import {
  TrendingUp,
  Shield,
  CheckCircle,
  XCircle,
  BarChart3,
  Activity,
  Globe,
  Database,
  ExternalLink,
  RefreshCw,
  AlertTriangle,
  Image as ImageIcon,
  Text,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useAppStore, Language } from "@/store/useAppStore";

// Local translations
const translations = {
  ar: {
    analyticsDashboard: "لوحة التحليلات",
    statsDesc: "إحصائيات مفصلة عن تحليلاتك",
    totalAnalyses: "إجمالي التحليلات",
    credible: "محتوى موثوق",
    fake: "محتوى مزيف",
    imageAnalyses: "تحليلات الصور",
    qualityIndices: "مؤشرات الجودة",
    credibilityIndex: "مؤشر المصداقية",
    viralityIndex: "مؤشر الانتشار",
    contentQualityIndex: "مؤشر جودة المحتوى",
    weeklyTrend: "الاتجاه الأسبوعي",
    officialSources: "مصادر التحقق الرسمية",
    verifiedThroughOfficial: "التحقق من خلال بيانات رسمية",
    verifiedDesc: "يتم التحقق من المحتوى باستخدام قواعد بيانات عالمية للتحقق من الحقائق بما في ذلك AFP و Reuters و BBC ومصادر موثوقة أخرى.",
  },
  en: {
    analyticsDashboard: "Analytics Dashboard",
    statsDesc: "Detailed statistics of your analyses",
    totalAnalyses: "Total Analyses",
    credible: "Credible",
    fake: "Fake",
    imageAnalyses: "Image Analyses",
    qualityIndices: "Quality Indices",
    credibilityIndex: "Credibility Index",
    viralityIndex: "Virality Index",
    contentQualityIndex: "Content Quality Index",
    weeklyTrend: "Weekly Trend",
    officialSources: "Official Verification Sources",
    verifiedThroughOfficial: "Verified through official data",
    verifiedDesc: "Content is verified using global fact-checking databases including AFP, Reuters, BBC, and other trusted sources.",
  },
} as const;

type TranslationKey = keyof typeof translations.ar;

function t(language: Language, key: TranslationKey): string {
  return translations[language][key] || key;
}

// Real fact-checking sources
const officialSources = [
  { name: "AFP Fact Check", url: "https://factcheck.afp.com", regionAr: "عالمي", regionEn: "Global" },
  { name: "Snopes", url: "https://www.snopes.com", regionAr: "أمريكا", regionEn: "USA" },
  { name: "PolitiFact", url: "https://www.politifact.com", regionAr: "أمريكا", regionEn: "USA" },
  { name: "Full Fact", url: "https://fullfact.org", regionAr: "بريطانيا", regionEn: "UK" },
  { name: "Reuters Fact Check", url: "https://www.reuters.com/fact-check", regionAr: "عالمي", regionEn: "Global" },
  { name: "BBC Reality Check", url: "https://www.bbc.com/news/reality_check", regionAr: "عالمي", regionEn: "Global" },
];

// Day names
const dayNames = {
  ar: ["السبت", "الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة"],
  en: ["Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri"],
};

export default function ReportPage() {
  const { stats, language } = useAppStore();
  
  // Calculate indices
  const credibilityIndex = stats.totalAnalysis > 0 
    ? Math.round((stats.credibleCount / stats.totalAnalysis) * 100) 
    : 60;
  
  const viralityIndex = Math.min(100, Math.round(stats.imageAnalysisCount * 15 + 30));
  
  const contentQualityIndex = Math.round(
    (credibilityIndex * 0.5 + viralityIndex * 0.3 + 20)
  );

  // Weekly data
  const weeklyData = dayNames[language].map((day, i) => ({
    day,
    value: Math.min(100, stats.totalAnalysis * (10 + i * 2) + 20),
  }));

  const maxWeekValue = Math.max(...weeklyData.map(d => d.value));

  return (
    <div className="space-y-6 pb-24">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center py-6"
      >
        <h1 className="text-2xl font-bold bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent">
          {t(language, "analyticsDashboard")}
        </h1>
        <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
          {t(language, "statsDesc")}
        </p>
      </motion.div>

      {/* Main Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="grid grid-cols-2 md:grid-cols-4 gap-4"
      >
        {[
          { 
            icon: BarChart3, 
            value: stats.totalAnalysis, 
            labelKey: "totalAnalyses" as const,
            color: "#3b82f6"
          },
          { 
            icon: CheckCircle, 
            value: stats.credibleCount, 
            labelKey: "credible" as const,
            color: "#22c55e"
          },
          { 
            icon: XCircle, 
            value: stats.fakeCount, 
            labelKey: "fake" as const,
            color: "#ef4444"
          },
          { 
            icon: ImageIcon, 
            value: stats.imageAnalysisCount, 
            labelKey: "imageAnalyses" as const,
            color: "#a855f7"
          },
        ].map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow overflow-hidden">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <motion.div 
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    className="w-12 h-12 rounded-2xl bg-gray-100 dark:bg-gray-800 flex items-center justify-center"
                  >
                    <stat.icon className="w-6 h-6" style={{ color: stat.color }} />
                  </motion.div>
                  <div>
                    <p className="text-2xl font-bold">{stat.value}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      {t(language, stat.labelKey)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {/* Quality Indices */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="border-0 shadow-xl overflow-hidden">
          <div className="h-1 bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500" />
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Activity className="w-5 h-5 text-purple-500" />
              {t(language, "qualityIndices")}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Credibility Index */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium flex items-center gap-2">
                  <Shield className="w-4 h-4 text-green-500" />
                  {t(language, "credibilityIndex")}
                </span>
                <span className="text-sm font-bold text-green-500">{credibilityIndex}%</span>
              </div>
              <Progress value={credibilityIndex} className="h-2" />
            </div>

            {/* Virality Index */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-purple-500" />
                  {t(language, "viralityIndex")}
                </span>
                <span className="text-sm font-bold text-purple-500">{viralityIndex}%</span>
              </div>
              <Progress value={viralityIndex} className="h-2" />
            </div>

            {/* Content Quality Index */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-blue-500" />
                  {t(language, "contentQualityIndex")}
                </span>
                <span className="text-sm font-bold text-blue-500">{contentQualityIndex}%</span>
              </div>
              <Progress value={contentQualityIndex} className="h-2" />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Weekly Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <BarChart3 className="w-5 h-5 text-purple-500" />
              {t(language, "weeklyTrend")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-end justify-between gap-2 h-32">
              {weeklyData.map((day, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-2">
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: `${(day.value / maxWeekValue) * 100}%` }}
                    transition={{ delay: i * 0.1, duration: 0.5 }}
                    className="w-full bg-gradient-to-t from-pink-500 via-purple-500 to-indigo-500 rounded-t-lg min-h-[8px] relative group cursor-pointer"
                  >
                    <motion.div
                      initial={{ opacity: 0 }}
                      whileHover={{ opacity: 1 }}
                      className="absolute -top-8 left-1/2 -translate-x-1/2 bg-gray-900 text-white text-xs px-2 py-1 rounded whitespace-nowrap"
                    >
                      {day.value}%
                    </motion.div>
                  </motion.div>
                  <span className="text-xs text-gray-500">{day.day}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Official Sources */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <Card className="border-0 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Database className="w-5 h-5 text-purple-500" />
              {t(language, "officialSources")}
              <Badge variant="secondary" className="mr-2 animate-pulse">
                <RefreshCw className="w-3 h-3 mr-1" />
                Live
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {officialSources.map((source, i) => (
                <motion.a
                  key={i}
                  href={source.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="flex items-center justify-between p-3 rounded-xl bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 transition-all group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-pink-500/20 to-purple-500/20 flex items-center justify-center">
                      <Globe className="w-5 h-5 text-purple-500" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{source.name}</p>
                      <p className="text-xs text-gray-500">
                        {language === "ar" ? source.regionAr : source.regionEn}
                      </p>
                    </div>
                  </div>
                  <ExternalLink className="w-4 h-4 text-gray-400 group-hover:text-purple-500 transition-colors" />
                </motion.a>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Verification Notice */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="p-4 rounded-2xl bg-gradient-to-r from-purple-50 via-pink-50 to-indigo-50 dark:from-purple-900/20 dark:via-pink-900/20 dark:to-indigo-900/20 border border-purple-100/50 dark:border-purple-800/50"
      >
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center flex-shrink-0">
            <Shield className="w-5 h-5 text-white" />
          </div>
          <div>
            <p className="font-semibold text-purple-700 dark:text-purple-300">
              {t(language, "verifiedThroughOfficial")}
            </p>
            <p className="text-sm text-purple-600 dark:text-purple-400 mt-1">
              {t(language, "verifiedDesc")}
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
