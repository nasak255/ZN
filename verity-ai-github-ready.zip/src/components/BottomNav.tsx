"use client";

import { motion } from "framer-motion";
import { Home, BarChart3, Settings, Search } from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import { cn } from "@/lib/utils";

export default function BottomNav() {
  const { currentPage, setCurrentPage, language } = useAppStore();
  
  const navItems = [
    { 
      id: "home" as const, 
      icon: Search, 
      labelAr: "تحليل",
      labelEn: "Analyze" 
    },
    { 
      id: "report" as const, 
      icon: BarChart3, 
      labelAr: "التقرير",
      labelEn: "Report" 
    },
    { 
      id: "settings" as const, 
      icon: Settings, 
      labelAr: "الإعدادات",
      labelEn: "Settings" 
    },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl border-t border-gray-200/50 dark:border-gray-700/50 safe-area-bottom">
      <div className="max-w-lg mx-auto px-6">
        <div className="flex items-center justify-around h-16">
          {navItems.map((item) => {
            const isActive = currentPage === item.id;
            const Icon = item.icon;
            
            return (
              <button
                key={item.id}
                onClick={() => setCurrentPage(item.id)}
                className={cn(
                  "relative flex flex-col items-center justify-center flex-1 h-full transition-all duration-200 active:scale-95",
                  isActive 
                    ? "text-purple-600 dark:text-purple-400" 
                    : "text-gray-400 dark:text-gray-500"
                )}
              >
                {isActive && (
                  <motion.div
                    layoutId="bottomNavIndicator"
                    className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-1 bg-gradient-to-r from-pink-500 to-purple-500 rounded-full"
                    transition={{ type: "spring", stiffness: 400, damping: 30 }}
                  />
                )}
                
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className={cn(
                    "flex flex-col items-center gap-1 px-4 py-2 rounded-2xl transition-all",
                    isActive && "bg-purple-50 dark:bg-purple-900/20"
                  )}
                >
                  <motion.div
                    animate={isActive ? { scale: [1, 1.2, 1] } : {}}
                    transition={{ duration: 0.3 }}
                  >
                    <Icon className={cn(
                      "w-6 h-6 transition-all",
                      isActive && "stroke-[2.5]"
                    )} />
                  </motion.div>
                  <span className={cn(
                    "text-xs font-medium transition-all",
                    isActive && "font-semibold"
                  )}>
                    {language === "ar" ? item.labelAr : item.labelEn}
                  </span>
                </motion.div>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
