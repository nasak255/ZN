"use client";

import { useState, useEffect, useCallback, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Download,
  X,
  Shield,
  Sparkles,
  Zap,
  Star,
  CheckCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{
    outcome: "accepted" | "dismissed";
    platform: string;
  }>;
  prompt(): Promise<void>;
}

// Helper function to check if dismissed recently
function getDismissedState(): { dismissed: boolean; recently: boolean } {
  if (typeof window === "undefined") return { dismissed: false, recently: false };
  
  const dismissed = localStorage.getItem("verity-ai-install-dismissed");
  if (!dismissed) return { dismissed: false, recently: false };
  
  const dismissedTime = parseInt(dismissed);
  const sevenDays = 7 * 24 * 60 * 60 * 1000;
  const recently = Date.now() - dismissedTime < sevenDays;
  
  return { dismissed: true, recently };
}

// Helper function to check if app is installed
function getInstalledState(): boolean {
  if (typeof window === "undefined") return false;
  
  return (
    window.matchMedia("(display-mode: standalone)").matches ||
    (window.navigator as any).standalone === true
  );
}

export default function InstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [showManualPrompt, setShowManualPrompt] = useState(false);
  
  // Calculate initial states using useMemo
  const isInstalled = useMemo(() => getInstalledState(), []);
  const dismissalState = useMemo(() => getDismissedState(), []);

  useEffect(() => {
    // Don't show if installed or recently dismissed
    if (isInstalled || dismissalState.recently) return;

    // Listen for install prompt
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);

    // Show prompt after 8 seconds
    const timer = setTimeout(() => {
      setIsVisible(true);
      setShowManualPrompt(true);
    }, 8000);

    // Listen for app installed
    const handleAppInstalled = () => {
      setIsVisible(false);
      setDeferredPrompt(null);
    };

    window.addEventListener("appinstalled", handleAppInstalled);

    return () => {
      clearTimeout(timer);
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
      window.removeEventListener("appinstalled", handleAppInstalled);
    };
  }, [isInstalled, dismissalState.recently]);

  const handleInstallClick = useCallback(async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") {
        setIsVisible(false);
      }
      setDeferredPrompt(null);
    } else {
      // Manual instructions for iOS
      setShowManualPrompt(true);
    }
  }, [deferredPrompt]);

  const handleDismiss = useCallback(() => {
    setIsVisible(false);
    // Store dismissal timestamp
    localStorage.setItem("verity-ai-install-dismissed", Date.now().toString());
  }, []);

  if (isInstalled) return null;

  const isIOS = typeof window !== "undefined" && 
    /iPad|iPhone|iPod/.test(window.navigator.userAgent);

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 100 }}
          transition={{ type: "spring", damping: 20 }}
          className="fixed bottom-0 left-0 right-0 z-50 p-4"
        >
          <Card className="max-w-md mx-auto border-0 shadow-2xl bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white overflow-hidden">
            {/* Animated Background */}
            <div className="absolute inset-0 overflow-hidden">
              <motion.div
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.3, 0.5, 0.3],
                }}
                transition={{ duration: 4, repeat: Infinity }}
                className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-gradient-to-br from-pink-500/30 to-purple-500/30 blur-3xl"
              />
              <motion.div
                animate={{
                  scale: [1.2, 1, 1.2],
                  opacity: [0.2, 0.4, 0.2],
                }}
                transition={{ duration: 5, repeat: Infinity }}
                className="absolute -bottom-10 -left-10 w-50 h-50 rounded-full bg-gradient-to-br from-purple-500/30 to-indigo-500/30 blur-3xl"
              />
            </div>

            <CardContent className="relative p-6">
              {/* Close Button */}
              <Button
                variant="ghost"
                size="sm"
                onClick={handleDismiss}
                className="absolute top-2 left-2 text-gray-400 hover:text-white hover:bg-white/10 rounded-full p-1 h-8 w-8"
              >
                <X className="w-4 h-4" />
              </Button>

              {/* Content */}
              <div className="flex items-start gap-4 mb-4 pt-2">
                <motion.div
                  animate={{ rotate: [0, 10, -10, 0] }}
                  transition={{ duration: 2, repeat: Infinity }}
                  className="w-14 h-14 rounded-2xl bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center flex-shrink-0 shadow-lg"
                >
                  <Shield className="w-7 h-7 text-white" />
                </motion.div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold mb-1">
                    ثبّت Verity AI الآن! 🚀
                  </h3>
                  <p className="text-sm text-gray-300">
                    احصل على أسرع تجربة للتحقق من المحتوى المضلل
                  </p>
                </div>
              </div>

              {/* Features */}
              <div className="grid grid-cols-2 gap-2 mb-4">
                {[
                  { icon: Zap, text: "وصول فوري" },
                  { icon: Star, text: "بدون إعلانات" },
                  { icon: Sparkles, text: "تحديثات مجانية" },
                  { icon: CheckCircle, text: "يعمل بدون إنترنت" },
                ].map((item, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="flex items-center gap-2 text-sm text-gray-300"
                  >
                    <item.icon className="w-4 h-4 text-pink-400" />
                    {item.text}
                  </motion.div>
                ))}
              </div>

              {/* Install Instructions for iOS */}
              {isIOS && showManualPrompt ? (
                <div className="bg-white/10 rounded-xl p-4 mb-4 text-sm">
                  <p className="mb-2 text-center">
                    للتثبيت على iPhone/iPad:
                  </p>
                  <ol className="space-y-1 text-gray-300 text-right">
                    <li>1. اضغط على زر المشاركة ↑</li>
                    <li>2. اختر &quot;إضافة إلى الشاشة الرئيسية&quot;</li>
                    <li>3. اضغط &quot;إضافة&quot;</li>
                  </ol>
                </div>
              ) : null}

              {/* Install Button */}
              <Button
                onClick={handleInstallClick}
                className="w-full bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 hover:from-pink-600 hover:via-purple-600 hover:to-indigo-600 text-white py-6 text-lg font-semibold rounded-xl shadow-lg"
              >
                <Download className="w-5 h-5 ml-2" />
                {isIOS ? "عرض التعليمات" : "تثبيت التطبيق"}
              </Button>

              <p className="text-xs text-gray-400 text-center mt-3">
                مجاني تماماً • يحفظ خصوصيتك • لا يشغل مساحة
              </p>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
