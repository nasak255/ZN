"use client";

import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Shield, Sparkles } from "lucide-react";

interface SplashScreenProps {
  onComplete: () => void;
}

const tips = [
  "💡 التحقق من المصدر خطوة أساسية للتحقق من المعلومات",
  "💡 الأخبار الكاذبة تنتشر أسرع من الأخبار الحقيقية",
  "💡 تحقق دائماً من تاريخ نشر الخبر",
  "💡 قارن الخبر مع مصادر موثوقة أخرى",
  "💡 الصور والفيديوهات قد تكون مزيفة",
  "💡 اللغة العاطفية قد تشير إلى محتوى مضلل",
];

export default function SplashScreen({ onComplete }: SplashScreenProps) {
  const [currentTip, setCurrentTip] = useState(0);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const tipInterval = setInterval(() => {
      setCurrentTip((prev) => (prev + 1) % tips.length);
    }, 2000);

    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 2;
      });
    }, 50);

    const timer = setTimeout(() => {
      onComplete();
    }, 3000);

    return () => {
      clearInterval(tipInterval);
      clearInterval(progressInterval);
      clearTimeout(timer);
    };
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }}
      className="fixed inset-0 bg-gradient-to-br from-gray-900 via-gray-800 to-black z-50 flex items-center justify-center cursor-pointer"
      onClick={onComplete}
    >
      {/* Animated Background Particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              background: `linear-gradient(135deg, rgba(236, 72, 153, 0.6), rgba(168, 85, 247, 0.4))`,
            }}
            animate={{
              y: [0, -100, 0],
              opacity: [0, 1, 0],
              scale: [0, 1, 0],
            }}
            transition={{
              duration: 3 + Math.random() * 2,
              repeat: Infinity,
              delay: i * 0.3,
            }}
          />
        ))}
      </div>

      {/* Main Content */}
      <div className="flex flex-col items-center justify-center relative z-10">
        {/* Logo */}
        <motion.div
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{
            type: "spring",
            stiffness: 200,
            damping: 15,
            duration: 0.8,
          }}
          className="relative"
        >
          <motion.div
            animate={{
              boxShadow: [
                "0 0 30px rgba(236, 72, 153, 0.3)",
                "0 0 60px rgba(168, 85, 247, 0.5)",
                "0 0 30px rgba(236, 72, 153, 0.3)",
              ],
            }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-32 h-32 md:w-40 md:h-40 rounded-3xl bg-gradient-to-br from-pink-500 via-purple-500 to-indigo-500 flex items-center justify-center relative"
          >
            <Shield className="w-16 h-16 md:w-20 md:h-20 text-white" />
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
              className="absolute inset-0 rounded-3xl border-2 border-white/20"
            />
          </motion.div>

          {/* Glow Effect */}
          <motion.div
            className="absolute inset-0 rounded-3xl"
            style={{
              background:
                "radial-gradient(circle, rgba(236, 72, 153, 0.25) 0%, rgba(168, 85, 247, 0.15) 40%, transparent 70%)",
              filter: "blur(20px)",
              transform: "scale(1.3)",
            }}
          />
        </motion.div>

        {/* Title */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="mt-8 text-center"
        >
          <h1
            className="text-4xl md:text-5xl font-bold text-white mb-3"
            style={{
              textShadow: "0 0 20px rgba(236, 72, 153, 0.5)",
            }}
          >
            Verity AI
          </h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-gray-300 text-base md:text-lg"
          >
            كشف المحتوى المضلل بالذكاء الاصطناعي
          </motion.p>
        </motion.div>

        {/* Progress Bar */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.7 }}
          className="w-48 mt-8"
        >
          <div className="relative w-full overflow-hidden rounded-full h-1.5 bg-gray-700">
            <motion.div
              className="h-full bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500"
              initial={{ width: "0%" }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.1 }}
            />
          </div>
        </motion.div>

        {/* Tips */}
        <AnimatePresence mode="wait">
          <motion.p
            key={currentTip}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
            className="mt-6 text-gray-400 text-sm text-center max-w-xs px-4"
          >
            {tips[currentTip]}
          </motion.p>
        </AnimatePresence>

        {/* Skip Text */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
          className="absolute bottom-8 text-gray-500 text-xs"
        >
          اضغط للتخطي
        </motion.p>

        {/* Decorative Elements */}
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
          className="absolute -top-20 -right-20 w-40 h-40 rounded-full bg-gradient-to-br from-pink-500/10 to-purple-500/10 blur-3xl"
        />
        <motion.div
          animate={{ rotate: -360 }}
          transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
          className="absolute -bottom-20 -left-20 w-60 h-60 rounded-full bg-gradient-to-br from-purple-500/10 to-indigo-500/10 blur-3xl"
        />
      </div>
    </motion.div>
  );
}
