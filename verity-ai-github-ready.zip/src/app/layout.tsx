import type { Metadata, Viewport } from "next";
import { Noto_Sans_Arabic } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const notoSansArabic = Noto_Sans_Arabic({
  variable: "--font-arabic",
  subsets: ["arabic"],
  weight: ["400", "500", "600", "700", "800"],
});

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ec4899" },
    { media: "(prefers-color-scheme: dark)", color: "#0f0f0f" },
  ],
};

export const metadata: Metadata = {
  title: "Verity AI - كشف المحتوى المضلل بالذكاء الاصطناعي",
  description: "منصة ذكية لكشف المحتوى المضلل والأخبار الكاذبة باستخدام الذكاء الاصطناعي",
  keywords: ["Verity AI", "كشف المحتوى المضلل", "الأخبار الكاذبة", "الذكاء الاصطناعي", "PWA"],
  authors: [{ name: "Verity AI Team" }],
  manifest: "/manifest.json",
  icons: {
    icon: [
      { url: "/favicon.png", sizes: "192x192", type: "image/png" },
      { url: "/verity-ai-logo.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [
      { url: "/favicon.png", sizes: "192x192", type: "image/png" },
    ],
  },
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Verity AI",
  },
  formatDetection: {
    telephone: false,
  },
  openGraph: {
    title: "Verity AI - كشف المحتوى المضلل بالذكاء الاصطناعي",
    description: "منصة ذكية لكشف المحتوى المضلل والأخبار الكاذبة باستخدام الذكاء الاصطناعي",
    type: "website",
    images: [{ url: "/verity-ai-logo.png", width: 512, height: 512 }],
  },
  twitter: {
    card: "summary_large_image",
    title: "Verity AI - كشف المحتوى المضلل",
    description: "منصة ذكية لكشف المحتوى المضلل والأخبار الكاذبة",
    images: ["/verity-ai-logo.png"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <head>
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="application-name" content="Verity AI" />
        <meta name="apple-mobile-web-app-title" content="Verity AI" />
        <link rel="apple-touch-icon" href="/favicon.png" />
      </head>
      <body
        className={`${notoSansArabic.variable} font-sans antialiased bg-background text-foreground`}
        style={{ fontFamily: "var(--font-arabic), sans-serif" }}
      >
        {children}
        <Toaster />
        <script
          dangerouslySetInnerHTML={{
            __html: `
              if ('serviceWorker' in navigator) {
                window.addEventListener('load', function() {
                  navigator.serviceWorker.register('/sw.js').then(
                    function(registration) {
                      console.log('SW registered: ', registration);
                    },
                    function(registrationError) {
                      console.log('SW registration failed: ', registrationError);
                    }
                  );
                });
              }
            `,
          }}
        />
      </body>
    </html>
  );
}
