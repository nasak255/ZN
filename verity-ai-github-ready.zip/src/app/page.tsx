"use client";

import { useState, useSyncExternalStore, useCallback } from "react";
import { AnimatePresence } from "framer-motion";
import SplashScreen from "@/components/SplashScreen";
import MainApp from "@/components/MainApp";

// Custom hook for localStorage with SSR support
function useLocalStorage(key: string, initialValue: string) {
  const storedValue = useSyncExternalStore(
    () => () => {},
    () => localStorage.getItem(key) ?? initialValue,
    () => initialValue
  );

  const setValue = useCallback(
    (value: string) => {
      localStorage.setItem(key, value);
    },
    [key]
  );

  return [storedValue, setValue] as const;
}

export default function Home() {
  const [hasSeenSplash, setHasSeenSplash] = useLocalStorage(
    "verity-ai-seen-splash",
    "false"
  );

  const showSplash = hasSeenSplash !== "true";

  const handleSplashComplete = useCallback(() => {
    setHasSeenSplash("true");
  }, [setHasSeenSplash]);

  return (
    <div className="min-h-screen flex flex-col">
      <AnimatePresence mode="wait">
        {showSplash && (
          <SplashScreen key="splash" onComplete={handleSplashComplete} />
        )}
      </AnimatePresence>

      {!showSplash && <MainApp key="main" />}
    </div>
  );
}
