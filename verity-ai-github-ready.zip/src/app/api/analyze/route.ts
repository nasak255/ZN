import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

// Security: Rate limiting store (in-memory for serverless)
const rateLimitStore = new Map<string, { count: number; resetTime: number }>();
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
const RATE_LIMIT_MAX = 10; // 10 requests per minute

// Security: Input sanitization
function sanitizeInput(input: string): string {
  // Remove potentially harmful characters
  return input
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/javascript:/gi, '')
    .replace(/on\w+\s*=/gi, '')
    .trim();
}

// Security: Validate URL
function isValidUrl(url: string): boolean {
  try {
    const parsed = new URL(url);
    return ['http:', 'https:'].includes(parsed.protocol);
  } catch {
    return false;
  }
}

// Security: Rate limiting
function checkRateLimit(clientId: string): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const record = rateLimitStore.get(clientId);
  
  if (!record || now > record.resetTime) {
    rateLimitStore.set(clientId, { count: 1, resetTime: now + RATE_LIMIT_WINDOW });
    return { allowed: true, remaining: RATE_LIMIT_MAX - 1 };
  }
  
  if (record.count >= RATE_LIMIT_MAX) {
    return { allowed: false, remaining: 0 };
  }
  
  record.count++;
  return { allowed: true, remaining: RATE_LIMIT_MAX - record.count };
}

// Security: Content length limit
const MAX_CONTENT_LENGTH = 10000;

interface SentimentAnalysis {
  overall: "positive" | "negative" | "neutral" | "mixed";
  score: number; // -100 to 100
  emotions: {
    joy: number;
    anger: number;
    fear: number;
    sadness: number;
    surprise: number;
    trust: number;
  };
  subjectivity: "objective" | "subjective" | "mixed";
  tone: string[];
}

interface AnalysisResult {
  credibilityScore: number;
  verdict: "credible" | "suspicious" | "fake" | "mixed";
  summary: string;
  keyPoints: string[];
  sources: string[];
  warnings: string[];
  positives: string[];
  sentiment: SentimentAnalysis;
  analyzedAt: string;
}

function parseAnalysisResponse(response: string): AnalysisResult {
  try {
    // Try to extract JSON from the response
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      
      // Ensure sentiment exists with defaults
      if (!parsed.sentiment) {
        parsed.sentiment = {
          overall: "neutral",
          score: 0,
          emotions: {
            joy: 0,
            anger: 0,
            fear: 0,
            sadness: 0,
            surprise: 0,
            trust: 50,
          },
          subjectivity: "mixed",
          tone: ["informative"],
        };
      }
      
      return parsed;
    }
  } catch (e) {
    console.error("Failed to parse JSON response:", e);
  }

  // Fallback: create a result from text analysis
  const lowerResponse = response.toLowerCase();
  let verdict: "credible" | "suspicious" | "fake" | "mixed" = "mixed";
  let credibilityScore = 50;

  if (
    lowerResponse.includes("موثوق") ||
    lowerResponse.includes("credible")
  ) {
    verdict = "credible";
    credibilityScore = 75;
  } else if (
    lowerResponse.includes("مزيف") ||
    lowerResponse.includes("fake")
  ) {
    verdict = "fake";
    credibilityScore = 20;
  } else if (
    lowerResponse.includes("مشبوه") ||
    lowerResponse.includes("suspicious")
  ) {
    verdict = "suspicious";
    credibilityScore = 40;
  }

  return {
    credibilityScore,
    verdict,
    summary: response.substring(0, 500),
    keyPoints: ["تحليل آلي"],
    sources: ["تحقق يدوي مطلوب"],
    warnings: ["فشل تحليل دقيق - يرجى المحاولة مرة أخرى"],
    positives: [],
    sentiment: {
      overall: "neutral",
      score: 0,
      emotions: { joy: 0, anger: 0, fear: 0, sadness: 0, surprise: 0, trust: 50 },
      subjectivity: "mixed",
      tone: ["informative"],
    },
    analyzedAt: new Date().toISOString(),
  };
}

export async function POST(request: NextRequest) {
  try {
    // Security: Get client identifier
    const clientId = request.headers.get("x-forwarded-for") || 
                     request.headers.get("x-real-ip") || 
                     "anonymous";
    
    // Security: Rate limiting
    const rateCheck = checkRateLimit(clientId);
    if (!rateCheck.allowed) {
      return NextResponse.json(
        { error: "تم تجاوز حد الطلبات. يرجى الانتظار دقيقة واحدة.", retryAfter: 60 },
        { status: 429, headers: { "Retry-After": "60" } }
      );
    }

    const body = await request.json();
    let { type, content } = body;

    // Security: Input validation
    if (!content || typeof content !== "string") {
      return NextResponse.json(
        { error: "المحتوى مطلوب للتحليل" },
        { status: 400 }
      );
    }

    // Security: Sanitize input
    content = sanitizeInput(content);

    // Security: Check content length
    if (content.length > MAX_CONTENT_LENGTH) {
      return NextResponse.json(
        { error: "المحتوى طويل جداً. الحد الأقصى 10,000 حرف." },
        { status: 400 }
      );
    }

    // Security: Validate URL type
    if (type === "url" && !isValidUrl(content)) {
      return NextResponse.json(
        { error: "الرابط غير صالح. يرجى إدخال رابط URL صحيح." },
        { status: 400 }
      );
    }

    if (content.trim().length === 0) {
      return NextResponse.json(
        { error: "المحتوى فارغ" },
        { status: 400 }
      );
    }

    // Initialize ZAI
    const zai = await ZAI.create();

    // Create system prompt for fake news detection with sentiment analysis
    const systemPrompt = `أنت خبير في كشف المحتوى المضلل والأخبار الكاذبة مع تحليل المشاعر. مهمتك تحليل المحتوى المقدم وتقديم تقييم شامل.

يجب أن ترد بتنسيق JSON فقط بالشكل التالي:
{
  "credibilityScore": <رقم من 0 إلى 100 يمثل نسبة المصداقية>,
  "verdict": "<credible|suspicious|fake|mixed>",
  "summary": "<ملخص التحليل بالعربية>",
  "keyPoints": ["<نقطة رئيسية 1>", "<نقطة رئيسية 2>"],
  "sources": ["<مصدر مقترح 1>", "<مصدر مقترح 2>"],
  "warnings": ["<تحذير 1>", "<تحذير 2>"],
  "positives": ["<نقطة إيجابية 1>", "<نقطة إيجابية 2>"],
  "sentiment": {
    "overall": "<positive|negative|neutral|mixed>",
    "score": <رقم من -100 إلى 100>,
    "emotions": {
      "joy": <0-100>,
      "anger": <0-100>,
      "fear": <0-100>,
      "sadness": <0-100>,
      "surprise": <0-100>,
      "trust": <0-100>
    },
    "subjectivity": "<objective|subjective|mixed>",
    "tone": ["<نبرة 1>", "<نبرة 2>"]
  },
  "analyzedAt": "<تاريخ التحليل ISO>"
}

معايير التقييم:
- credible: المحتوى موثوق ومطابق للحقائق (70-100%)
- suspicious: المحتوى مشبوه ويحتاج تحقق (40-69%)
- fake: المحتوى مزيف أو مضلل (0-39%)
- mixed: المحتوى يحتوي على خليط من الحقائق والمعلومات المشبوهة

تحليل المشاعر:
- overall: المشاعر العامة للمحتوى
- score: درجة المشاعر (-100 سلبي جداً إلى 100 إيجابي جداً)
- emotions: نسبة كل عاطفة في المحتوى (0-100)
- subjectivity: هل المحتوى موضوعي أم ذاتي
- tone: النبرات المستخدمة (مثل: تحذيري، عاطفي، رسمي، تحريضي)

عند التحليل، ركز على:
1. مصداقية المعلومات والادعاءات
2. وجود مصادر موثوقة
3. لغة التحريض أو العاطفة المبالغ فيها
4. التحقق من الحقائق المذكورة
5. مقارنة مع معلومات معروفة
6. تحليل النبرة والمشاعر المستخدمة

أجب بـ JSON فقط بدون أي نص إضافي.`;

    let userPrompt = "";

    if (type === "url") {
      userPrompt = `قم بتحليل هذا الرابط والمحتوى المحتمل فيه: ${content}
      
قدم تحليلاً شاملاً لمصداقية الرابط والمحتوى المتوقع منه مع تحليل المشاعر.`;
    } else {
      userPrompt = `قم بتحليل هذا النص وتقييم مدى مصداقيته مع تحليل المشاعر:

"${content}"

قدم تحليلاً شاملاً يتضمن:
1. تقييم المصداقية
2. النقاط الإيجابية (إن وجدت)
3. التحذيرات والمخاطر
4. المصادر المقترحة للتحقق
5. تحليل المشاعر والنبرة`;
    }

    // Get completion from LLM
    const completion = await zai.chat.completions.create({
      messages: [
        { role: "assistant", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      thinking: { type: "disabled" },
    });

    const response = completion.choices[0]?.message?.content || "";

    // Parse the response
    const result = parseAnalysisResponse(response);

    // Add rate limit headers to response
    const responseHeaders = {
      "X-RateLimit-Remaining": rateCheck.remaining.toString(),
      "X-RateLimit-Limit": RATE_LIMIT_MAX.toString(),
    };

    return NextResponse.json({ result }, { headers: responseHeaders });
  } catch (error) {
    console.error("Analysis error:", error);
    return NextResponse.json(
      { error: "حدث خطأ أثناء التحليل" },
      { status: 500 }
    );
  }
}
