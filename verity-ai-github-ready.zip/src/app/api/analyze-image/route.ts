import { NextRequest, NextResponse } from "next/server";
import ZAI from "z-ai-web-dev-sdk";

// Security: Rate limiting store
const rateLimitStore = new Map<string, { count: number; resetTime: number }>();
const RATE_LIMIT_WINDOW = 60 * 1000; // 1 minute
const RATE_LIMIT_MAX = 5; // 5 image analyses per minute (lower for images)

// Security: Rate limiting
function checkRateLimit(clientId: string): { allowed: boolean; remaining: number } {
  const now = Date.now();
  const record = rateLimitStore.get(clientId);
  
  if (!record || now > record.resetTime) {
    rateLimitStore.set(clientId, { count: 1, resetTime: now + RATE_LIMIT_WINDOW });
    return { allowed: true, remaining: RATE_LIMIT_MAX - 1 };
  }
  
  if (record.count >= RATE_LIMIT_MAX) {
    return { allowed: false, remaining: 0 };
  }
  
  record.count++;
  return { allowed: true, remaining: RATE_LIMIT_MAX - record.count };
}

// Security: Max image size (10MB base64 encoded)
const MAX_IMAGE_SIZE = 10 * 1024 * 1024;

// Security: Allowed image types
const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

interface SentimentAnalysis {
  overall: "positive" | "negative" | "neutral" | "mixed";
  score: number;
  emotions: {
    joy: number;
    anger: number;
    fear: number;
    sadness: number;
    surprise: number;
    trust: number;
  };
  subjectivity: "objective" | "subjective" | "mixed";
  tone: string[];
}

interface ImageAnalysisResult {
  description: string;
  viralityScore: number;
  viralityPrediction: "low" | "medium" | "high" | "viral";
  contentClassification: string[];
  sentiment: SentimentAnalysis;
  emotionalImpact: string;
  targetAudience: string[];
  engagementPrediction: {
    likes: string;
    shares: string;
    comments: string;
  };
  recommendations: string[];
  warnings: string[];
  hashtags: string[];
  bestPostingTime: string;
  contentWarnings: string[];
  analyzedAt: string;
}

function parseImageAnalysisResponse(response: string): ImageAnalysisResult {
  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      
      // Ensure sentiment exists with defaults
      if (!parsed.sentiment) {
        parsed.sentiment = {
          overall: "neutral",
          score: 0,
          emotions: {
            joy: 0,
            anger: 0,
            fear: 0,
            sadness: 0,
            surprise: 0,
            trust: 50,
          },
          subjectivity: "mixed",
          tone: ["visual"],
        };
      }
      
      // Ensure contentWarnings exists
      if (!parsed.contentWarnings) {
        parsed.contentWarnings = [];
      }
      
      return parsed;
    }
  } catch (e) {
    console.error("Failed to parse JSON response:", e);
  }

  // Fallback result
  return {
    description: "تم تحليل الصورة بنجاح",
    viralityScore: 50,
    viralityPrediction: "medium",
    contentClassification: ["محتوى عام"],
    sentiment: {
      overall: "neutral",
      score: 0,
      emotions: { joy: 0, anger: 0, fear: 0, sadness: 0, surprise: 0, trust: 50 },
      subjectivity: "mixed",
      tone: ["visual"],
    },
    emotionalImpact: "متوسط",
    targetAudience: ["الجمهور العام"],
    engagementPrediction: {
      likes: "متوسط",
      shares: "منخفض",
      comments: "متوسط",
    },
    recommendations: ["حاول إضافة عناصر أكثر جاذبية"],
    warnings: [],
    contentWarnings: [],
    hashtags: ["#محتوى"],
    bestPostingTime: "المساء",
    analyzedAt: new Date().toISOString(),
  };
}

// Security: Validate base64 image
function validateBase64Image(base64: string): { valid: boolean; error?: string } {
  // Check if it's a valid data URL
  if (!base64.startsWith('data:image/')) {
    return { valid: false, error: "صيغة الصورة غير صالحة" };
  }
  
  // Extract MIME type
  const mimeMatch = base64.match(/^data:(image\/\w+);/);
  if (!mimeMatch) {
    return { valid: false, error: "لم يتم التعرف على نوع الصورة" };
  }
  
  const mimeType = mimeMatch[1];
  if (!ALLOWED_IMAGE_TYPES.includes(mimeType)) {
    return { valid: false, error: `نوع الصورة غير مدعوم. الأنواع المدعومة: ${ALLOWED_IMAGE_TYPES.join(', ')}` };
  }
  
  // Check size
  if (base64.length > MAX_IMAGE_SIZE) {
    return { valid: false, error: "حجم الصورة كبير جداً. الحد الأقصى 10 ميجابايت" };
  }
  
  return { valid: true };
}

export async function POST(request: NextRequest) {
  try {
    // Security: Get client identifier
    const clientId = request.headers.get("x-forwarded-for") || 
                     request.headers.get("x-real-ip") || 
                     "anonymous";
    
    // Security: Rate limiting
    const rateCheck = checkRateLimit(clientId);
    if (!rateCheck.allowed) {
      return NextResponse.json(
        { error: "تم تجاوز حد طلبات تحليل الصور. يرجى الانتظار دقيقة واحدة.", retryAfter: 60 },
        { status: 429, headers: { "Retry-After": "60" } }
      );
    }

    const body = await request.json();
    const { image } = body;

    if (!image) {
      return NextResponse.json(
        { error: "الصورة مطلوبة للتحليل" },
        { status: 400 }
      );
    }

    // Security: Validate image
    const imageValidation = validateBase64Image(image);
    if (!imageValidation.valid) {
      return NextResponse.json(
        { error: imageValidation.error },
        { status: 400 }
      );
    }

    // Initialize ZAI
    const zai = await ZAI.create();

    const systemPrompt = `أنت خبير في تحليل الصور وتوقع انتشار المحتوى على وسائل التواصل الاجتماعي مع تحليل المشاعر.

قم بتحليل الصورة المقدمة وأعطني تقريراً شاملاً يتضمن:

1. وصف دقيق للصورة
2. توقع درجة الانتشار (0-100)
3. تصنيف الانتشار: low/medium/high/viral
4. تصنيف المحتوى (مثال: ترفيهي، تعليمي، إخباري، عاطفي، تحفيزي)
5. تحليل المشاعر
6. التأثير العاطفي
7. الجمهور المستهدف
8. توقع التفاعل (إعجابات، مشاركات، تعليقات)
9. توصيات لتحسين الانتشار
10. تحذيرات المحتوى (إن وجدت)
11. هاشتاجات مقترحة
12. أفضل وقت للنشر

أجب بتنسيق JSON فقط بالشكل التالي:
{
  "description": "<وصف الصورة>",
  "viralityScore": <رقم 0-100>,
  "viralityPrediction": "<low|medium|high|viral>",
  "contentClassification": ["<تصنيف1>", "<تصنيف2>"],
  "sentiment": {
    "overall": "<positive|negative|neutral|mixed>",
    "score": <رقم من -100 إلى 100>,
    "emotions": {
      "joy": <0-100>,
      "anger": <0-100>,
      "fear": <0-100>,
      "sadness": <0-100>,
      "surprise": <0-100>,
      "trust": <0-100>
    },
    "subjectivity": "<objective|subjective|mixed>",
    "tone": ["<نبرة 1>"]
  },
  "emotionalImpact": "<وصف التأثير العاطفي>",
  "targetAudience": ["<الجمهور1>", "<الجمهور2>"],
  "engagementPrediction": {
    "likes": "<منخفض|متوسط|عالي|عالي جداً>",
    "shares": "<منخفض|متوسط|عالي|عالي جداً>",
    "comments": "<منخفض|متوسط|عالي|عالي جداً>"
  },
  "recommendations": ["<توصية1>", "<توصية2>"],
  "warnings": ["<تحذير1>"],
  "contentWarnings": ["<تحذير محتوى 1>"],
  "hashtags": ["#هاشتاق1", "#هاشتاق2"],
  "bestPostingTime": "<أفضل وقت>",
  "analyzedAt": "<تاريخ ISO>"
}

أجب بـ JSON فقط بدون أي نص إضافي.`;

    // For image analysis, we pass a truncated description to the LLM
    // In a real scenario, we would use a vision model
    const userPrompt = `قم بتحليل هذه الصورة وتوقع مدى انتشارها مع تحليل المشاعر:

الصورة: ${image.substring(0, 200)}...

قدم تحليلاً شاملاً يفيد صانعي المحتوى في فهم إمكانية انتشار صورهم مع تحليل المشاعر والنبرة.`;

    // Get completion from LLM
    const completion = await zai.chat.completions.create({
      messages: [
        { role: "assistant", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      thinking: { type: "disabled" },
    });

    const response = completion.choices[0]?.message?.content || "";
    const result = parseImageAnalysisResponse(response);

    // Add rate limit headers to response
    const responseHeaders = {
      "X-RateLimit-Remaining": rateCheck.remaining.toString(),
      "X-RateLimit-Limit": RATE_LIMIT_MAX.toString(),
    };

    return NextResponse.json({ result }, { headers: responseHeaders });
  } catch (error) {
    console.error("Image analysis error:", error);
    return NextResponse.json(
      { error: "حدث خطأ أثناء تحليل الصورة" },
      { status: 500 }
    );
  }
}
