import { create } from "zustand";
import { persist } from "zustand/middleware";

export type Language = "ar" | "en";

interface AppState {
  // Language
  language: Language;
  setLanguage: (lang: Language) => void;
  
  // Theme
  isDarkMode: boolean;
  toggleTheme: () => void;
  
  // Navigation
  currentPage: "home" | "report" | "settings";
  setCurrentPage: (page: "home" | "report" | "settings") => void;
  
  // Notifications
  notificationsEnabled: boolean;
  toggleNotifications: () => void;
  
  // Stats
  stats: {
    totalAnalysis: number;
    credibleCount: number;
    fakeCount: number;
    suspiciousCount: number;
    mixedCount: number;
    imageAnalysisCount: number;
  };
  updateStats: (type: "credible" | "fake" | "suspicious" | "mixed" | "image") => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      // Language
      language: "ar",
      setLanguage: (lang) => {
        if (typeof document !== "undefined") {
          document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
          document.documentElement.lang = lang;
        }
        set({ language: lang });
      },
      
      // Theme
      isDarkMode: true,
      toggleTheme: () => {
        set((state) => {
          const newMode = !state.isDarkMode;
          if (typeof document !== "undefined") {
            document.documentElement.classList.toggle("dark", newMode);
            document.documentElement.classList.toggle("light", !newMode);
          }
          return { isDarkMode: newMode };
        });
      },
      
      // Navigation
      currentPage: "home",
      setCurrentPage: (page) => set({ currentPage: page }),
      
      // Notifications
      notificationsEnabled: true,
      toggleNotifications: () =>
        set((state) => ({ notificationsEnabled: !state.notificationsEnabled })),
      
      // Stats
      stats: {
        totalAnalysis: 47,
        credibleCount: 28,
        fakeCount: 12,
        imageAnalysisCount: 15,
        suspiciousCount: 5,
        mixedCount: 2,
      },
      updateStats: (type) =>
        set((state) => {
          const stats = { ...state.stats };
          stats.totalAnalysis += 1;
          if (type === "credible") stats.credibleCount += 1;
          if (type === "fake") stats.fakeCount += 1;
          if (type === "suspicious") stats.suspiciousCount += 1;
          if (type === "mixed") stats.mixedCount += 1;
          if (type === "image") stats.imageAnalysisCount += 1;
          return { stats };
        }),
    }),
    {
      name: "verity-ai-storage",
      partialize: (state) => ({
        language: state.language,
        isDarkMode: state.isDarkMode,
        notificationsEnabled: state.notificationsEnabled,
        stats: state.stats,
      }),
    }
  )
);
