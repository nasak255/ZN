export type Language = "ar" | "en";

export const translations = {
  ar: {
    // Navigation
    home: "الرئيسية",
    report: "التقرير",
    settings: "الإعدادات",
    homeNav: "الرئيسية",
    reportNav: "التقرير",
    settingsNav: "الإعدادن",
    
    // Tabs
    text: "نص",
    url: "رابط",
    image: "صورة",
    
    // Analysis
    analyzeContent: "تحليل المحتوى",
    analyzeImage: "تحليل الصورة",
    analyze: "تحليل",
    analyzing: "جاري التحليل...",
    enterText: "أدخل النص الذي تريد تحليله...",
    enterUrl: "أدخل رابط URL هنا...",
    uploadImage: "اضغط لرفع صورة أو اسحبها هنا",
    supportedFormats: "PNG, JPG, WEBP",
    
    // Results
    credibilityScore: "درجة المصداقية",
    viralityScore: "درجة الانتشار",
    verdict: "النتيجة",
    credible: "موثوق",
    suspicious: "مشبوه",
    fake: "مزيف",
    mixed: "مختلط",
    summary: "ملخص التحليل",
    positives: "نقاط إيجابية",
    warnings: "تحذيرات",
    keyPoints: "النقاط الرئيسية",
    sources: "المصادر",
    
    // Image Analysis
    imageDescription: "وصف الصورة",
    contentClassification: "تصنيف المحتوى",
    sentiment: "المشاعر",
    emotionalImpact: "التأثير العاطفي",
    targetAudience: "الجمهور المستهدف",
    engagementPrediction: "توقع التفاعل",
    likes: "الإعجابات",
    shares: "المشاركات",
    comments: "التعليقات",
    recommendedHashtags: "هاشتاجات مقترحة",
    bestPostingTime: "أفضل وقت للنشر",
    recommendations: "توصيات لزيادة الانتشار",
    
    // Virality
    lowVirality: "انتشار منخفض",
    mediumVirality: "انتشار متوسط",
    highVirality: "انتشار عالي",
    viralContent: "انتشار واسع 🚀",
    
    // Language
    language: "اللغة",
    arabic: "العربية",
    english: "English",
    darkMode: "الوضع الليلي",
    lightMode: "الوضع النهاري",
    notifications: "الإشعارات",
    enableNotifications: "تفعيل الإشعارات",
    
    // Report
    dailyStats: "إحصائيات اليوم",
    totalAnalysis: "إجمالي التحليلات",
    credibleContent: "المحتوى الموثوق",
    fakeContent: "المحتوى المزيف",
    imageAnalysis: "تحليلات الصور",
    weeklyTrend: "الاتجاه الأسبوعي",
    credibilityIndex: "مؤشر المصداقية",
    viralityIndex: "مؤشر الانتشار",
    contentQualityIndex: "مؤشر جودة المحتوى",
    officialDataSources: "مصادر البيانات الرسمية",
    
    // History
    history: "السجل",
    noHistory: "لا توجد تحليلات سابقة",
    clearHistory: "مسح السجل",
    
    // Stats
    totalAnalysisCount: "إجمالي التحليلات",
    imageAnalysisCount: "تحليلات الصور",
  },
  en: {
    // Navigation
    home: "Home",
    report: "Report",
    settings: "Settings",
    homeNav: "Home",
    reportNav: "Report",
    settingsNav: "Settings",
    
    // Tabs
    text: "Text",
    url: "URL",
    image: "Image",
    
    // Analysis
    analyzeContent: "Analyze Content",
    analyzeImage: "Analyze Image",
    analyze: "Analyze",
    analyzing: "Analyzing...",
    enterText: "Enter the text you want to analyze...",
    enterUrl: "Enter URL here...",
    uploadImage: "Click to upload or drag an image",
    supportedFormats: "PNG, JPG, WEBP",
    
    // Results
    credibilityScore: "Credibility Score",
    viralityScore: "Virality Score",
    verdict: "Verdict",
    credible: "Credible",
    suspicious: "Suspicious",
    fake: "Fake",
    mixed: "Mixed",
    summary: "Analysis Summary",
    positives: "Positive Points",
    warnings: "Warnings",
    keyPoints: "Key Points",
    sources: "Sources",
    
    // Image Analysis
    imageDescription: "Image Description",
    contentClassification: "Content Classification",
    sentiment: "Sentiment",
    emotionalImpact: "Emotional Impact",
    targetAudience: "Target Audience",
    engagementPrediction: "Engagement Prediction",
    likes: "Likes",
    shares: "Shares",
    comments: "Comments",
    recommendedHashtags: "Recommended Hashtags",
    bestPostingTime: "Best Posting Time",
    recommendations: "Recommendations",
    
    // Virality
    lowVirality: "Low Reach",
    mediumVirality: "Medium Reach",
    highVirality: "High Reach",
    viralContent: "Viral Content 🚀",
    
    // Language
    language: "Language",
    arabic: "العربية",
    english: "English",
    darkMode: "Dark Mode",
    lightMode: "Light Mode",
    notifications: "Notifications",
    enableNotifications: "Enable Notifications",
    
    // Report
    dailyStats: "Daily Stats",
    totalAnalysis: "Total Analysis",
    credibleContent: "Credible Content",
    fakeContent: "Fake Content",
    imageAnalysis: "Image Analysis",
    weeklyTrend: "Weekly Trend",
    credibilityIndex: "Credibility Index",
    viralityIndex: "Virality Index",
    contentQualityIndex: "Content Quality Index",
    officialDataSources: "Official Data Sources",
    
    // History
    history: "History",
    noHistory: "No previous analyses",
    clearHistory: "Clear History",
    
    // Stats
    totalAnalysisCount: "Total Analysis",
    imageAnalysisCount: "Image Analysis",
  },
};

export type TranslationKey = keyof typeof translations.ar;

export function getTranslation(lang: Language, key: TranslationKey): string {
  return translations[lang][key] || key;
}
